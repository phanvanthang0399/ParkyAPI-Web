﻿namespace ParkyWeb
{
    /// <summary>
    /// 
    /// </summary>
    public static class SD
    {
        /// <summary>
        /// api domain url
        /// </summary>
        public static string APIBaseUrl = "https://localhost:7200/";
        public static string NationalParkAPIPath = APIBaseUrl + "api/v1/nationalParks/";
        public static string TrailAPIPath = APIBaseUrl + "api/v1/trails/";

    }
}
