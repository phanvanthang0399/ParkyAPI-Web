﻿using ParkyWeb.Repository.IRepository;
using System.Net.Http;

namespace ParkyWeb.Repository
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public UnitOfWork(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;

            NationalPark = new NationalParkRepository(_httpClientFactory);

            Trail = new TrailRepository(_httpClientFactory);
        }

        public ITrailRepository Trail { get; private set; }

        public INationalParkRepository NationalPark { get; private set; }
    }
}
