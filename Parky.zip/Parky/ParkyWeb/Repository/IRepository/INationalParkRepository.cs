﻿using ParkyWeb.Models;

namespace ParkyWeb.Repository.IRepository
{
    public interface INationalParkRepository : IRepository<NationalPark>
    {

    }
}
