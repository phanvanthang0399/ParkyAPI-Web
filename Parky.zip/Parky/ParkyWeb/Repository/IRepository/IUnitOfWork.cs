﻿namespace ParkyWeb.Repository.IRepository
{
    public interface IUnitOfWork
    {
        ITrailRepository Trail { get; }
        INationalParkRepository NationalPark { get; }
    }
}
