﻿using ParkyWeb.Models;

namespace ParkyWeb.Repository.IRepository
{
    public interface ITrailRepository : IRepository<Trail>
    {

    }
}
