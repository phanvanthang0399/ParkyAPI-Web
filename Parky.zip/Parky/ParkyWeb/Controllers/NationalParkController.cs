﻿using Microsoft.AspNetCore.Mvc;
using ParkyWeb.Models;
using ParkyWeb.Repository.IRepository;

namespace ParkyWeb.Controllers
{
    public class NationalParkController : Controller
    {
        private readonly IUnitOfWork _db;

        public NationalParkController(IUnitOfWork db)
        {
            _db = db;
        }

        public IActionResult Index()
        {
            return View(new NationalPark() { });
        }

        public async Task<IActionResult> Upsert(int? id)
        {
            NationalPark obj = new NationalPark();

            if (id == null)
            {
                return View(obj);
            }

            obj = await _db.NationalPark.GetAsync(SD.NationalParkAPIPath, id.GetValueOrDefault());

            if (obj == null)
            {
                return NotFound();
            }

            return View(obj);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Upsert(NationalPark obj)
        {
            if (ModelState.IsValid)
            {
                var files = HttpContext.Request.Form.Files;

                if (files.Count > 0)
                {
                    byte[] pic1 = null;

                    using (var fs1 = files[0].OpenReadStream())
                    {
                        using (var ms1 = new MemoryStream())
                        {
                            fs1.CopyTo(ms1);
                            pic1 = ms1.ToArray();
                        }
                    }
                    obj.Picture = pic1;
                }
                else
                {
                    var objFromDb = await _db.NationalPark.GetAsync(SD.NationalParkAPIPath, obj.Id);

                    obj.Picture = objFromDb.Picture;
                }

                if (obj.Id == 0)
                {
                    await _db.NationalPark.CreateAsync(SD.NationalParkAPIPath, obj);
                }
                else
                {
                    await _db.NationalPark.UpdateAsync(SD.NationalParkAPIPath + obj.Id, obj);
                }

                return RedirectToAction(nameof(Index));
            }
            else
            {
                return View(obj);
            }
        }

        public async Task<IActionResult> GetAllNationalPark()
        {
            return Json(new { data = await _db.NationalPark.GetAllAsync(SD.NationalParkAPIPath) });
        }

        [HttpDelete]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int? id)
        {
            NationalPark obj = new NationalPark();

            if (id == null)
            {
                return NotFound();
            }

            if (!await _db.NationalPark.DeleteAsync(SD.NationalParkAPIPath, id.GetValueOrDefault()))
            {
                return NotFound();
            }

            return View("Index");
        }
    }
}
