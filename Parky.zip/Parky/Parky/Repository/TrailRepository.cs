﻿using Microsoft.EntityFrameworkCore;
using Parky.Data;
using Parky.Models;
using Parky.Repository.IRepository;

namespace Parky.Repository
{
    public class TrailRepository : ITrailRepository
    {
        private readonly ApplicationDbContext _db;

        public TrailRepository(ApplicationDbContext db)
        {
            _db = db;
        }

        public bool Save()
        {
            return _db.SaveChanges() > 0;
        }

        public bool CreateTrail(Trail trail)
        {
            _db.Trails.Add(trail);
            return Save();
        }

        public bool DeleteTrail(Trail trail)
        {
            _db.Trails.Remove(trail);
            return Save();
        }

        public Trail GetTrail(int id)
        {
            return _db.Trails.Include(x => x.NationalPark).FirstOrDefault(x => x.Id.Equals(id));
        }

        public ICollection<Trail> GetTrails()
        {
            return _db.Trails.Include(x => x.NationalPark).OrderBy(x => x.Name).ToList();
        }

        public bool TrailExists(string name)
        {
            return _db.Trails.Any(x => x.Name.ToLower().Trim().Equals(name.ToLower().Trim()));
        }

        public bool TrailExists(int id)
        {
            return _db.Trails.Any(x => x.Id.Equals(id));
        }

        

        public bool UpdateTrail(Trail trail)
        {
            _db.Trails.Update(trail);
            return Save();
        }

        public ICollection<Trail> GetTrailsInNationalPark(int npId)
        {
            return _db.Trails.Include(x => x.NationalPark).Where(x => x.NationalParkId.Equals(npId)).ToList();
        }
    }
}
