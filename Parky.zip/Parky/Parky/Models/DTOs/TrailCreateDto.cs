﻿using System.ComponentModel.DataAnnotations;
using static Parky.Models.Trail;

namespace Parky.Models.DTOs
{
    public class TrailCreateDto
    {
        [Required]
        public string Name { get; set; }
        [Required]
        public double Distance { get; set; }
        public DifficultType Difficulty { get; set; }
        [Required]
        public int NationalParkId { get; set; }
        public DateTime DateCreated { get; set; }
    }
}
