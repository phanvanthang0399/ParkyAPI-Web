using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Parky;
using Parky.Data;
using Parky.Mapper;
using Parky.Repository;
using Parky.Repository.IRepository;
using Swashbuckle.AspNetCore.SwaggerGen;
using System.Reflection;

var builder = WebApplication.CreateBuilder(args);



var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");

builder.Services.AddDbContext<ApplicationDbContext>(x => x.UseSqlServer(connectionString));

builder.Services.AddScoped<INationalParkRepository, NationalParkRepository>();
builder.Services.AddScoped<ITrailRepository, TrailRepository>();
builder.Services.AddApiVersioning(options =>
{
    options.AssumeDefaultVersionWhenUnspecified = true;
    options.DefaultApiVersion = new ApiVersion(1, 0);
    options.ReportApiVersions = true;
});

builder.Services.AddVersionedApiExplorer(options => options.GroupNameFormat = "'v'VVV");
//
builder.Services.AddAutoMapper(typeof(ParkyMappings));


// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddTransient<IConfigureOptions<SwaggerGenOptions>, ConfigureSwaggerOptions>();
builder.Services.AddSwaggerGen();

//builder.Services.AddSwaggerGen(options =>
//{
//    options.SwaggerDoc("ParkyOpenAPISpec", new Microsoft.OpenApi.Models.OpenApiInfo()
//    {
//        Title = "Parky API",
//        Version = "1",
//        Description = "Udemy Parky API",
//        Contact = new Microsoft.OpenApi.Models.OpenApiContact()
//        {
//            Email = "thangbarca99@gmail.com",
//            Name = "Phan Thang",
//            Url = new Uri("https://www.facebook.com/PVThang99")
//        },
//        License = new Microsoft.OpenApi.Models.OpenApiLicense()
//        {
//            Name = "MIT License",
//            Url = new Uri("https://en.wikipedia.org/wiki/MIT License")
//        }
//    });

//    //options.SwaggerDoc("ParkyOpenAPISpecTrails", new Microsoft.OpenApi.Models.OpenApiInfo()
//    //{
//    //    Title = "Parky API Trails",
//    //    Version = "1",
//    //    Description = "Udemy Parky API Trails",
//    //    Contact = new Microsoft.OpenApi.Models.OpenApiContact()
//    //    {
//    //        Email = "thangbarca99@gmail.com",
//    //        Name = "Phan Thang",
//    //        Url = new Uri("https://www.facebook.com/PVThang99")
//    //    },
//    //    License = new Microsoft.OpenApi.Models.OpenApiLicense()
//    //    {
//    //        Name = "MIT License",
//    //        Url = new Uri("https://en.wikipedia.org/wiki/MIT License")
//    //    }
//    //});

//    var xmlCommentFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";

//    var cmlCommentsFullPath = Path.Combine(AppContext.BaseDirectory, xmlCommentFile);

//    options.IncludeXmlComments(cmlCommentsFullPath);

//});

var app = builder.Build();

var provider = app.Services.GetRequiredService<IApiVersionDescriptionProvider>();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}
app.UseHttpsRedirection();
app.UseSwagger();

app.UseSwaggerUI(options =>
{
    foreach (var desc in provider.ApiVersionDescriptions)
    {
        options.SwaggerEndpoint($"/swagger/{desc.GroupName}/swagger.json", desc.GroupName.ToUpperInvariant());

        options.RoutePrefix = "";
    }
});

//app.UseSwaggerUI(options =>
//{
//    options.SwaggerEndpoint("/swagger/ParkyOpenAPISpec/swagger.json", "Parky API");
//    //options.SwaggerEndpoint("/swagger/ParkyOpenAPISpecTrails/swagger.json", "Parky API Trails");
//    options.RoutePrefix = "";
//});


app.UseAuthorization();

app.MapControllers();

app.Run();
